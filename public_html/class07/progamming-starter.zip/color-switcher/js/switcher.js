document.getElementById('grayButton').onclick = switchGray;

function switchGray() {
  document.getElementsByTagName('body')[0].className = 'one'; 
}

