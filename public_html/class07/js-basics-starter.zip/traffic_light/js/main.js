function clearLights() {
    document.getElementById('stopLight').style.backgroundColor = "black";
}

function illuminateRed() {
    clearLights();
    document.getElementById('stopLight').style.backgroundColor = "red";
}

document.getElementById('stopButton').onclick = illuminateRed;
