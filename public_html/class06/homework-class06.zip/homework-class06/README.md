# Startup Matchmaker Lab

Use startup\_matchmaker\_comp.png and [HTML 5 Boilerplate](http://html5boilerplate.com) to get started!

You may need to Google:

* background-image
* cover
* del
* ins
* overflow

Fonts Used:

* Source Sans Pro
* Merriweather
* Oswald

[Image credit: http://www.flickr.com/photos/mikeschinkel/2733534094/](http://www.flickr.com/photos/mikeschinkel/2733534094/)
