$('.hamburger').on('click', function() {
  $('.main-nav').slideToggle();
});


//create varialble blockgroups, then in that, store the result of the jquery selection//
