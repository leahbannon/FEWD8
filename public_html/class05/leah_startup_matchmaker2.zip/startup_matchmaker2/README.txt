Image from http://www.flickr.com/photos/mikeschinkel/2733534094/

You may need to Google:

* background-image
* cover
* del
* ins
* overflow

Fonts Used: 
* Source Sans Pro
* Merriweather
* Oswald